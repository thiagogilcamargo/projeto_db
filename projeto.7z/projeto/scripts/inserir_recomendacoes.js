const mongoose = require('mongoose');
const Recomendacao = require('../models/Recomendacao');
const Cliente = require('../models/Cliente');

mongoose.connect('mongodb://localhost:27017/recomendacoes', {
    useNewUrlParser: true,
    useUnifiedTopology: true
}).then(async () => {
    const recomendacoes = [
        { cliente_id: "1", recomendacao: "Investir em startups de tecnologia focadas em inteligência artificial." },
        { cliente_id: "2", recomendacao: "Diversificar investimentos em fundos imobiliários." },
        // Adicione mais recomendações conforme necessário
    ];

    await Recomendacao.insertMany(recomendacoes);
    console.log("Recomendações inseridas com sucesso!");
    mongoose.disconnect();
}).catch(err => {
    console.error("Erro ao conectar ao MongoDB:", err);
});
