const mongoose = require('mongoose');
const Cliente = require('../models/Cliente');

mongoose.connect('mongodb://localhost:27017/recomendacoes', {
    useNewUrlParser: true,
    useUnifiedTopology: true
}).then(async () => {
    const clientes = [
        { nome: "João Silva", email: "joao@email.com", capital: 100000, objetivos: ["crescimento", "inovação"], telefone: "11987654321", setor_interesse: "Tecnologia", localizacao: "São Paulo" },
        { nome: "Maria Oliveira", email: "maria@email.com", capital: 75000, objetivos: ["segurança", "crescimento"], telefone: "21987654321", setor_interesse: "Finanças", localizacao: "Rio de Janeiro" },
        // Adicione mais clientes conforme necessário
    ];

    await Cliente.insertMany(clientes);
    console.log("Clientes inseridos com sucesso!");
    mongoose.disconnect();
}).catch(err => {
    console.error("Erro ao conectar ao MongoDB:", err);
});
